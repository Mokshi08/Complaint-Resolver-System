package com.example.demo;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.model.Complaint;
import com.example.model.User;
import com.example.dao.ComplaintDao;
import com.example.dao.UserDao;

@Controller
public class Home {
	
	@Autowired
	public UserDao userDao;
	@Autowired
	public ComplaintDao complaintDao;
	
	
	@RequestMapping({"/","/home"})
	public String Hello(User user,Model model)
	{
		 model.addAttribute("user", user);
		return "index";
		
	}
	
//	@RequestMapping("/login")
//	public String login() 
//	{
//			return "login";
//		}
	
	
	@RequestMapping("/register")
	public String registration() 
	{
		return "registration";
	}

	
    
//    @GetMapping("/form")
//    public String formGet() {
//        return "registration";
//    }
    
    @PostMapping("/form")
    public String formPost(User user, Model model) {
        model.addAttribute("user", user);
        System.out.println("controller===>"+user.getUserName());
       userDao.insertUser(user);
        return "index";
    }
    
    @RequestMapping(value="/valid",method=RequestMethod.POST)
    public String login(User user, Model model) {
        model.addAttribute("user", user);
//		  String name=user.getUser_FullName();
//		  String pass=user.getUser_Password();
//		  System.out.println(name+" "+pass);
        User loginUser=userDao.retrieve(user);
        System.out.println(loginUser);
        if(loginUser!=null)
        {
        	return "complaint";
        }
        return "Invalid";
    }
    
    @RequestMapping("/ComplaintWater")
	public String water() 
	{
			return "water";
		}
    @RequestMapping("/ComplaintElectricity")
 	public String electricity() 
 	{
 			return "electricity";
 		}
    @RequestMapping("/ComplaintPollution")
 	public String pollution() 
 	{
 			return "pollution";
 		}
    @RequestMapping("/ComplaintDrainage")
 	public String drainage() 
 	{
 			return "drain";
 		}
    @RequestMapping("/ComplaintTransport")
 	public String transport() 
 	{
 			return "transport";
 		}
    @RequestMapping("/ComplaintRoad")
 	public String road() 
 	{
 			return "road";
 		}
	@PostMapping("/complaints")
   // @RequestMapping(value="/complaints",method=RequestMethod.POST)
	  public String addComplaint(Complaint complaint,User user, Model model) {
        model.addAttribute("complaint", complaint);
        //model.addAttribute("user", user);
        //System.out.println("controller===>"+user.getUser_FullName());
        System.out.println("User Id:"+user.getUserId());
        System.out.println("from controller"+complaint.getUser());
        System.out.println("in complaints");
       complaintDao.insertComplaint(complaint,user);

        return "complaint_success";
    }
	
	@RequestMapping(value="/listUser",method=RequestMethod.GET)
	public String listUsers(Model model) {
		model.addAttribute("user",new User());
		model.addAttribute("listUsers", this.userDao.getAllUsers());

		model.addAttribute("complaint",new Complaint());
		model.addAttribute("listUsers", this.complaintDao.getAllComplaints());

		return "listComplaints";
		
	}
//	@RequestMapping(value="/listUsers",method=RequestMethod.GET)
//	 public String listComplaints(Model model) {
//		
//		model.addAttribute("complaint",new Complaint());
//		model.addAttribute("listComplaints", this.complaintDao.getAllComplaints());
//		return "listComplaints";
//		
//	}
	@RequestMapping(value="/test",method=RequestMethod.GET)
	public @ResponseBody String test(Model model) {
		
		complaintDao.test();
		return "succes";
	}
	
	
}
